--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2 (Debian 16.2-1.pgdg120+2)
-- Dumped by pg_dump version 16.2 (Ubuntu 16.2-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: Organization; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."Organization" ("orgId", "orgName") FROM stdin;
djsce	SVKM's Dwarkadas J Sanghvi College of Engineering
pict	Pune Institute of Information Technology
pps	Pune Public School
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."User" ("userId", "userOrgId", "userName", "userType", "userPassword", "userDisplayName") FROM stdin;
58e77573-94ea-44a0-b55f-62c28c193aca	djsce	djsce-admin	Administrator	$2b$10$p5c23WzgYLeiVtS3OXBJCe0IhDtg17fIPvbgSOTpmKHS0vd4kmfV6	djsce Admin
32dc7a48-1377-464c-a57c-28d3c5a59671	djsce	arnitdo	Teacher	$2b$10$g8BEYUpLU.WlSmmQ.VCb6Ot/vgpkktfPXjIR0.6mm4AWAUvjC.SY6	Arnav Deo
1e18c07f-31ec-4ba2-9a74-31f597e77d29	djsce	vaxad	Student	$2b$10$r7muj46qIvAKZl/..IN87.DhRTumcbykyaDOQI7LY4NoVuVphEhjC	Varad Prabhu
9fca692b-79d5-425c-b011-a36f8f61f2c1	djsce	student	Student	$2b$10$GES/QL8T6oQg/osMJOGG2.fsN9LNXkfZvPio25q36xEGbZ.cUyPHu	DJSCE Student
9819aaf1-7bc6-4646-9a67-3fe19766b27b	djsce	teacher	Teacher	$2b$10$mJvxjhQCYVDmUcxXpr9jruB2yBK9tL.FdzpclREuEJGjzKnx5hJrK	DJSCE Teacher
36b63d04-2e34-464b-afc9-b9e9e35d7f9b	djsce	admin	Administrator	$2b$10$WNc.oPzHqSSt2v5hvUqS3eQ/hLxTspot0ov8dCvjPB12LJcSHK4wW	DJSCE Admin
6e464e49-2d19-41e4-8a19-62b5a681898d	pict	pict-admin	Administrator	$2b$10$gVFvg887ebq76LgGWX9DM.5.0nllq/YyE.peo8FMigCbPiscGhnSK	pict Admin
f1490a74-8e3b-4497-ab6d-60b422defaa0	pps	pps-admin	Administrator	$2b$10$J92hLq5vqzAacnBxjQJPmeuAKiMIBLqMHrTbAKA4i.rvDdiBypuxu	pps Admin
c6e8fdfc-aff3-45c9-a82e-a223a802264f	pps	varad	Student	$2b$10$lmajy.wSaHzBhCfy551ny.Jj4ENxcJydClFbt1KdN38mPkgSWfw8y	Varad
f27a96b8-8461-4dac-abef-5e559e2ad7ec	pps	arnav	Student	$2b$10$hf3Cwrv6G9yZBTY6eNcemeOmwx6KAZL/KVbVf2T/bQ0rvzrQT9s9a	Arnav Deo
3afacab1-dd21-441a-b996-3cdba2e245f9	pps	prinkal	Student	$2b$10$IE87TLisTIuAS.A6jsOh8.IQB3oZpamnKjKNEuAonv5WOAI3ovYsK	Prinkal Doshi
4beca881-89a2-44c9-b22a-64e32c822a61	pps	mihir	Student	$2b$10$aM.0.I4cWDgRiOfr5u2hg.U/NwQSmGL/OAQpWjj.1FsKI5sFqJnlK	Mihir Panchal
797e98b3-6f5c-432f-8e3d-dac00b86278b	pps	rishabh	Student	$2b$10$vtFFBj80Q8T/rJeOTEAUQOMH/fF/sB1ih2b9qvCUy.sjjYJ8X.2OG	Rishabh Pandey
6740f44c-73d3-46e1-a47f-f877c645021a	pps	ashok	Teacher	$2b$10$vm2ToiiyagrX2NNF8vQHcuXOfwhBoe8I.qSo30wK9ZkbEG8wGJ7eS	Ashok Patade
ed36ac45-1277-4e6f-a34f-a07b938771eb	pps	aniket	Teacher	$2b$10$7jCx9IIPJ482haIK7vt0be5Z7TDv4/48sqWdIOLj/3bqMgwpG7pbS	Aniket Kore
cb409461-e98b-40fe-843e-6c15b7b6b0a4	pps	meera	Teacher	$2b$10$RBh0vu/Q/EytYCCnkp2rhe.1rtXfGAPxGnkwVV7kG2eQfUlCm2hRu	Meera Narvekar
ee6d17cb-8d53-4556-8540-5538279055a8	pps	pranit	Teacher	$2b$10$GZhHJOX7/TanF4ZoCm8.qefoheu0uYJKUSoO88eMKmQ7wFlK4J.OS	Pranit Bari
\.


--
-- Data for Name: Classroom; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."Classroom" ("classroomId", "classroomName", "classroomOrgId", "facultyUserId") FROM stdin;
455ffa00-9c88-4583-9ad8-1c46527f5a8d	SE C3 POA Theory	djsce	32dc7a48-1377-464c-a57c-28d3c5a59671
a0348703-d8cf-424a-be90-ea90d94b6aa7	SE C3 MATHEMATICS	djsce	9819aaf1-7bc6-4646-9a67-3fe19766b27b
48117e9d-245a-435d-b319-e60d48fb3fbd	FE CS BASICS	djsce	9819aaf1-7bc6-4646-9a67-3fe19766b27b
d3b9b775-187b-4f96-a513-1e7ac155ed32	9A SCIENCE	pps	ed36ac45-1277-4e6f-a34f-a07b938771eb
cc4f08c5-f570-4904-9ac2-bad23e66f0b4	9A GEOGRAPHY	pps	cb409461-e98b-40fe-843e-6c15b7b6b0a4
f49cf3a3-cbfb-41d2-a5be-82a2c8392ddd	9B POLITICAL SCIENCE	pps	ed36ac45-1277-4e6f-a34f-a07b938771eb
8f8e946e-45ce-4b31-a81e-f91fdedcafe7	9B COMPUTER SCIENCE	pps	ed36ac45-1277-4e6f-a34f-a07b938771eb
d790f8a5-884b-488f-994a-116df3826f53	9C ECONOMICS	pps	ed36ac45-1277-4e6f-a34f-a07b938771eb
3964838c-6050-42f0-846b-f0fadd2fdbb9	9B SCIENCE	pps	6740f44c-73d3-46e1-a47f-f877c645021a
49c3f729-5ec4-4a22-a64f-bd1f2060e28e	9C POLITICAL SCIENCE	pps	6740f44c-73d3-46e1-a47f-f877c645021a
501db15e-28f5-4216-9d69-72aa64e58ef5	9C SCIENCE	pps	ee6d17cb-8d53-4556-8540-5538279055a8
b43f368f-c602-491e-aac5-9070e3448fe5	9D POLITICAL SCIENCE	pps	6740f44c-73d3-46e1-a47f-f877c645021a
4a2b96d5-2f51-4d56-9e0d-a7fd85b7397d	SE IT	djsce	32dc7a48-1377-464c-a57c-28d3c5a59671
2645a6a2-e8f2-4e27-b390-72991f7bd61f	TE C2 FLAT	pps	6740f44c-73d3-46e1-a47f-f877c645021a
f187a171-7ba4-497b-969a-26a95843e600	FE C1 JAVA	pps	ed36ac45-1277-4e6f-a34f-a07b938771eb
eb6bddbc-6625-4b81-ad24-b93873f7234c	HISTORY	pps	ed36ac45-1277-4e6f-a34f-a07b938771eb
1c897697-26cb-49ac-9b13-6aa5ee46abcc	PHYSICS 1	pps	cb409461-e98b-40fe-843e-6c15b7b6b0a4
\.


--
-- Data for Name: Assessment; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."Assessment" ("assessmentId", "assessmentTitle", "classroomId") FROM stdin;
3a1774c6-7af6-48a3-b2f0-41baf9c2f69f	Structure of Atom Test	d3b9b775-187b-4f96-a513-1e7ac155ed32
06f0f84f-24bf-44da-bc72-f9aed3addd7c	Matter around us Test	d3b9b775-187b-4f96-a513-1e7ac155ed32
2171ab70-a083-4953-8b3b-7d8fa8aced23	CS Week 1	8f8e946e-45ce-4b31-a81e-f91fdedcafe7
\.


--
-- Data for Name: AssessmentAttempt; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."AssessmentAttempt" ("attemptId", "userId", "assessmentId") FROM stdin;
\.


--
-- Data for Name: AssessmentQuestion; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."AssessmentQuestion" ("questionId", "questionText", "questionMarks", "questionAssesmentId") FROM stdin;
865713d0-5d0b-4785-9215-5c67e4a94313	What is matter	10	3a1774c6-7af6-48a3-b2f0-41baf9c2f69f
9aa57e13-d51c-4b89-9b88-261d5a7e8c90	Distinguish between neutrons and protons	10	3a1774c6-7af6-48a3-b2f0-41baf9c2f69f
9daeda7c-e052-4d0c-aa4a-8161d3b092e7	What is Matter?	5	06f0f84f-24bf-44da-bc72-f9aed3addd7c
69058682-2b21-4311-9cd2-a126930e411d	What is Mass?	5	06f0f84f-24bf-44da-bc72-f9aed3addd7c
6d209df5-fc46-4858-baec-d550646caba3	What is Inertia	5	06f0f84f-24bf-44da-bc72-f9aed3addd7c
62a60ad2-556b-4ae3-95ab-4f04acdeb3d6	What is a queue? Describe various operations on queue?	8	2171ab70-a083-4953-8b3b-7d8fa8aced23
f1d9df6c-b0ea-4569-9c88-30d06aabd878	What is the front or rear of a queue?	6	2171ab70-a083-4953-8b3b-7d8fa8aced23
\.


--
-- Data for Name: AssessmentResponse; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."AssessmentResponse" ("responseId", "responseText", "responseObtainedMarks", "responseQuestionId", "attemptId") FROM stdin;
\.


--
-- Data for Name: Assignment; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."Assignment" ("assignmentId", "assignmentName", "assignmentClassroomId") FROM stdin;
\.


--
-- Data for Name: AssignmentSubmission; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."AssignmentSubmission" ("submissionId", "submissionTimestamp", "submissionObjectKey", "submissionUserId") FROM stdin;
\.


--
-- Data for Name: ClassroomEnrollment; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."ClassroomEnrollment" ("userId", "classroomId") FROM stdin;
1e18c07f-31ec-4ba2-9a74-31f597e77d29	455ffa00-9c88-4583-9ad8-1c46527f5a8d
9fca692b-79d5-425c-b011-a36f8f61f2c1	48117e9d-245a-435d-b319-e60d48fb3fbd
9fca692b-79d5-425c-b011-a36f8f61f2c1	a0348703-d8cf-424a-be90-ea90d94b6aa7
c6e8fdfc-aff3-45c9-a82e-a223a802264f	d3b9b775-187b-4f96-a513-1e7ac155ed32
c6e8fdfc-aff3-45c9-a82e-a223a802264f	cc4f08c5-f570-4904-9ac2-bad23e66f0b4
c6e8fdfc-aff3-45c9-a82e-a223a802264f	f49cf3a3-cbfb-41d2-a5be-82a2c8392ddd
c6e8fdfc-aff3-45c9-a82e-a223a802264f	8f8e946e-45ce-4b31-a81e-f91fdedcafe7
4beca881-89a2-44c9-b22a-64e32c822a61	d3b9b775-187b-4f96-a513-1e7ac155ed32
4beca881-89a2-44c9-b22a-64e32c822a61	f49cf3a3-cbfb-41d2-a5be-82a2c8392ddd
4beca881-89a2-44c9-b22a-64e32c822a61	8f8e946e-45ce-4b31-a81e-f91fdedcafe7
4beca881-89a2-44c9-b22a-64e32c822a61	d790f8a5-884b-488f-994a-116df3826f53
f27a96b8-8461-4dac-abef-5e559e2ad7ec	d790f8a5-884b-488f-994a-116df3826f53
f27a96b8-8461-4dac-abef-5e559e2ad7ec	8f8e946e-45ce-4b31-a81e-f91fdedcafe7
f27a96b8-8461-4dac-abef-5e559e2ad7ec	d3b9b775-187b-4f96-a513-1e7ac155ed32
f27a96b8-8461-4dac-abef-5e559e2ad7ec	cc4f08c5-f570-4904-9ac2-bad23e66f0b4
f27a96b8-8461-4dac-abef-5e559e2ad7ec	f49cf3a3-cbfb-41d2-a5be-82a2c8392ddd
797e98b3-6f5c-432f-8e3d-dac00b86278b	f49cf3a3-cbfb-41d2-a5be-82a2c8392ddd
797e98b3-6f5c-432f-8e3d-dac00b86278b	8f8e946e-45ce-4b31-a81e-f91fdedcafe7
797e98b3-6f5c-432f-8e3d-dac00b86278b	49c3f729-5ec4-4a22-a64f-bd1f2060e28e
797e98b3-6f5c-432f-8e3d-dac00b86278b	cc4f08c5-f570-4904-9ac2-bad23e66f0b4
3afacab1-dd21-441a-b996-3cdba2e245f9	cc4f08c5-f570-4904-9ac2-bad23e66f0b4
3afacab1-dd21-441a-b996-3cdba2e245f9	d3b9b775-187b-4f96-a513-1e7ac155ed32
3afacab1-dd21-441a-b996-3cdba2e245f9	f49cf3a3-cbfb-41d2-a5be-82a2c8392ddd
3afacab1-dd21-441a-b996-3cdba2e245f9	d790f8a5-884b-488f-994a-116df3826f53
\.


--
-- Data for Name: ClassroomResource; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."ClassroomResource" ("resourceId", "resourceName", "resourceObjectKey", "classroomId") FROM stdin;
4ac3ac18-c959-4678-9cbf-d3e5fc01e254	React Resources.pdf	orgs/djsce/classrooms/455ffa00-9c88-4583-9ad8-1c46527f5a8d/resources/react-resources.pdf	455ffa00-9c88-4583-9ad8-1c46527f5a8d
77f1aeef-407f-44f5-95ea-ad7cb9e93c8a	8086_Intel.pdf	orgs/djsce/classrooms/455ffa00-9c88-4583-9ad8-1c46527f5a8d/resources/8086_intel.pdf	455ffa00-9c88-4583-9ad8-1c46527f5a8d
c3210e9c-3ffb-4fc1-85ee-3a4574094351	80x86InstructionReference.pdf	orgs/djsce/classrooms/455ffa00-9c88-4583-9ad8-1c46527f5a8d/resources/80x86instructionreference.pdf	455ffa00-9c88-4583-9ad8-1c46527f5a8d
ec4158e2-9fc1-499c-8bdb-7ac19ad21ee3	S139_MBS_EXP-4_MANAV.pdf	orgs/djsce/classrooms/4a2b96d5-2f51-4d56-9e0d-a7fd85b7397d/resources/s139_mbs_exp-4_manav.pdf	4a2b96d5-2f51-4d56-9e0d-a7fd85b7397d
9b1ff4cd-10c0-4064-a409-1e46d7976e1b	QB_Answers.docx	orgs/djsce/classrooms/455ffa00-9c88-4583-9ad8-1c46527f5a8d/resources/qb_answers.docx	455ffa00-9c88-4583-9ad8-1c46527f5a8d
ec9772e9-93f9-4fd3-a1e9-c0cc8873a6c4	S139_MBS_EXP-4_MANAV.pdf	orgs/djsce/classrooms/455ffa00-9c88-4583-9ad8-1c46527f5a8d/resources/s139_mbs_exp-4_manav.pdf	455ffa00-9c88-4583-9ad8-1c46527f5a8d
314b2b70-13be-489e-a8f0-ede7bbd9994d	cs_queue.pdf	orgs/pps/classrooms/8f8e946e-45ce-4b31-a81e-f91fdedcafe7/resources/cs_queue.pdf	8f8e946e-45ce-4b31-a81e-f91fdedcafe7
\.


--
-- Data for Name: Lecture; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."Lecture" ("lectureId", title, "lectureStartTimestamp", "lectureEndTimestamp", "lectureClassroomId") FROM stdin;
ceff43b3-ac8f-4bec-a00b-9560b8634647	DATA TYPES	2024-03-28 16:00:48.772	2024-03-28 16:30:48.772	a0348703-d8cf-424a-be90-ea90d94b6aa7
998368f8-a63c-4f27-a74d-6ae758dd3f58	POA Theory - 8086 Microprocessor	2024-03-28 08:04:47.261	2024-03-31 02:44:47.261	455ffa00-9c88-4583-9ad8-1c46527f5a8d
551bb07c-8130-4bdc-9427-aecd69506a82	Matter around us	2024-03-29 06:30:02.13	2024-03-29 08:15:02.13	d3b9b775-187b-4f96-a513-1e7ac155ed32
db4e6032-71f7-401d-99d9-acd03206a887	Structure of Atom	2024-03-29 08:30:06.202	2024-03-29 10:00:06.202	d3b9b775-187b-4f96-a513-1e7ac155ed32
990cd90d-9fef-434c-82b7-dbefc869f0e6	Democracy	2024-03-29 10:30:09.92	2024-03-29 11:00:09.92	f49cf3a3-cbfb-41d2-a5be-82a2c8392ddd
e77aa886-4f3f-409f-a99b-d95ac7a875ea	Rights	2024-03-30 04:30:00	2024-03-30 05:30:00	f49cf3a3-cbfb-41d2-a5be-82a2c8392ddd
73b51aeb-f1ae-486d-b2d0-7b78af324fb3	Elections	2024-03-31 06:30:00	2024-03-31 07:30:00	f49cf3a3-cbfb-41d2-a5be-82a2c8392ddd
86c2ccc4-2452-4223-9ae5-ef612a4bed0f	Internet	2024-03-29 06:30:35.742	2024-03-29 07:25:35.742	8f8e946e-45ce-4b31-a81e-f91fdedcafe7
0bc8e4e8-4265-43c8-99dd-00d8c9dec7f7	Security	2024-03-30 10:30:00	2024-03-30 12:00:00	8f8e946e-45ce-4b31-a81e-f91fdedcafe7
02b7aa74-1948-4e69-b2f7-f6028378dde2	Poverty	2024-03-31 08:30:00	2024-03-31 09:25:00	d790f8a5-884b-488f-994a-116df3826f53
aec9b3db-a306-4f09-bcad-3b54481eec9e	People Resources	2024-03-29 10:30:16.061	2024-03-29 11:30:16.061	d790f8a5-884b-488f-994a-116df3826f53
5682cd33-a890-489d-b7d5-615390cf86a4	DATA STRUCTURES	2024-03-29 11:00:56.895	2024-03-29 12:00:56.895	a0348703-d8cf-424a-be90-ea90d94b6aa7
3c3335ac-d228-4b31-95e8-9e35612fee44	ARRAYS	2024-03-29 08:00:23.25	2024-03-29 09:00:23.25	a0348703-d8cf-424a-be90-ea90d94b6aa7
04437812-ac6e-4327-a8ad-19b2369679e1	STRINGS	2024-03-30 06:15:00	2024-03-30 07:15:00	a0348703-d8cf-424a-be90-ea90d94b6aa7
74591c3e-beaf-4458-8636-987e69b4da29	HASHMAPS	2024-03-30 04:30:00	2024-03-30 05:30:00	a0348703-d8cf-424a-be90-ea90d94b6aa7
\.


--
-- Data for Name: LectureAttendance; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."LectureAttendance" ("lectureId", "userId") FROM stdin;
e77aa886-4f3f-409f-a99b-d95ac7a875ea	797e98b3-6f5c-432f-8e3d-dac00b86278b
e77aa886-4f3f-409f-a99b-d95ac7a875ea	4beca881-89a2-44c9-b22a-64e32c822a61
990cd90d-9fef-434c-82b7-dbefc869f0e6	f27a96b8-8461-4dac-abef-5e559e2ad7ec
0bc8e4e8-4265-43c8-99dd-00d8c9dec7f7	f27a96b8-8461-4dac-abef-5e559e2ad7ec
0bc8e4e8-4265-43c8-99dd-00d8c9dec7f7	c6e8fdfc-aff3-45c9-a82e-a223a802264f
\.


--
-- Data for Name: LectureTranscript; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."LectureTranscript" ("transcriptId", "lectureId", "transcriptText") FROM stdin;
4f9bf096-9000-41bf-86f2-d15ccb12fe6a	ceff43b3-ac8f-4bec-a00b-9560b8634647	Title: Understanding Gravitation: A Fundamental Force in the CosmosGood morning/afternoon/evening, ladies and gentlemen. Today, we embark on a journey through one of the fundamental forces that govern our universe: gravitation. From the humble apple falling from a tree to the majestic dance of galaxies across the cosmos, gravity shapes the very fabric of space and time. In this lecture, we'll explore the intricacies of gravity, its historical significance, its role in the cosmos, and its profound implications for our understanding of the universe.Let's begin with a simple observation: everything that has mass attracts other mass. This seemingly trivial statement encapsulates the essence of gravitation, as formulated by Sir Isaac Newton in his groundbreaking work, the Principia Mathematica. Newton's law of universal gravitation states that every particle in the universe attracts every other particle with a force that is directly proportional to the product of their masses and inversely proportional to the square of the distance between their centers.The concept of gravity is not a recent discovery. Throughout history, civilizations have grappled with the mysteries of celestial motion and the forces that govern them. Ancient civilizations such as the Greeks and the Babylonians pondered the motions of the stars and planets, attributing them to the whims of the gods. It wasn't until the scientific revolution of the 17th century that humanity began to unravel the true nature of gravitational forces.In 1687, Isaac Newton published his magnum opus, the Principia Mathematica, wherein he laid the groundwork for classical mechanics and the theory of universal gravitation. Newton's laws of motion provided a comprehensive framework for understanding the dynamics of objects on Earth and in the heavens. His law of universal gravitation, combined with his laws of motion, offered a unified explanation for the orbits of the planets, the motion of the tides, and the trajectory of projectiles.While Newton's theory of gravity reigned supreme for over two centuries, it wasn't until the early 20th century that its limitations became apparent. Enter Albert Einstein and his theory of general relativity. Einstein revolutionized our understanding of gravity by proposing that it is not merely a force between masses but rather a curvature of spacetime caused by the presence of mass and energy.According to general relativity, massive objects such as stars and planets warp the fabric of spacetime, much like placing a heavy ball on a stretched rubber sheet. This curvature of spacetime dictates the paths that objects follow, causing them to move along the curved trajectories we perceive as gravitational attraction. General relativity has been confirmed through numerous experiments and observations, from the bending of light around massive objects to the detection of gravitational waves rippling through the cosmos.The recent detection of gravitational waves by instruments such as LIGO and VIRGO has opened up new avenues for studying the universe. Gravitational waves are ripples in spacetime produced by cataclysmic events such as the collision of black holes or the merger of neutron stars. By detecting these waves, scientists can probe the most extreme phenomena in the cosmos and test the predictions of general relativity with unprecedented precision.In conclusion, gravitation stands as one of the cornerstones of modern physics, shaping the dynamics of celestial bodies and the evolution of the cosmos. From Newton's apple to Einstein's spacetime curvature, our understanding of gravity has evolved significantly over the centuries, yet many mysteries remain. As we continue to unravel the secrets of the universe, the force of gravity will undoubtedly remain a central focus of scientific inquiry for generations to come.Thank you for joining me on this journey through the realm of gravitation. I hope this lecture has deepened your appreciation for the profound significance of gravity in shaping the cosmos. Let us continue to explore, question, and marvel at the wonders of the universe. Good day.
a8f0a6c3-aacb-4259-98e9-ca387f02c66a	ceff43b3-ac8f-4bec-a00b-9560b8634647	Title: Understanding Gravitation: A Fundamental Force in the CosmosGood morning/afternoon/evening, ladies and gentlemen. Today, we embark on a journey through one of the fundamental forces that govern our universe: gravitation. From the humble apple falling from a tree to the majestic dance of galaxies across the cosmos, gravity shapes the very fabric of space and time. In this lecture, we'll explore the intricacies of gravity, its historical significance, its role in the cosmos, and its profound implications for our understanding of the universe.Let's begin with a simple observation: everything that has mass attracts other mass. This seemingly trivial statement encapsulates the essence of gravitation, as formulated by Sir Isaac Newton in his groundbreaking work, the Principia Mathematica. Newton's law of universal gravitation states that every particle in the universe attracts every other particle with a force that is directly proportional to the product of their masses and inversely proportional to the square of the distance between their centers.The concept of gravity is not a recent discovery. Throughout history, civilizations have grappled with the mysteries of celestial motion and the forces that govern them. Ancient civilizations such as the Greeks and the Babylonians pondered the motions of the stars and planets, attributing them to the whims of the gods. It wasn't until the scientific revolution of the 17th century that humanity began to unravel the true nature of gravitational forces.In 1687, Isaac Newton published his magnum opus, the Principia Mathematica, wherein he laid the groundwork for classical mechanics and the theory of universal gravitation. Newton's laws of motion provided a comprehensive framework for understanding the dynamics of objects on Earth and in the heavens. His law of universal gravitation, combined with his laws of motion, offered a unified explanation for the orbits of the planets, the motion of the tides, and the trajectory of projectiles.While Newton's theory of gravity reigned supreme for over two centuries, it wasn't until the early 20th century that its limitations became apparent. Enter Albert Einstein and his theory of general relativity. Einstein revolutionized our understanding of gravity by proposing that it is not merely a force between masses but rather a curvature of spacetime caused by the presence of mass and energy.According to general relativity, massive objects such as stars and planets warp the fabric of spacetime, much like placing a heavy ball on a stretched rubber sheet. This curvature of spacetime dictates the paths that objects follow, causing them to move along the curved trajectories we perceive as gravitational attraction. General relativity has been confirmed through numerous experiments and observations, from the bending of light around massive objects to the detection of gravitational waves rippling through the cosmos.The recent detection of gravitational waves by instruments such as LIGO and VIRGO has opened up new avenues for studying the universe. Gravitational waves are ripples in spacetime produced by cataclysmic events such as the collision of black holes or the merger of neutron stars. By detecting these waves, scientists can probe the most extreme phenomena in the cosmos and test the predictions of general relativity with unprecedented precision.In conclusion, gravitation stands as one of the cornerstones of modern physics, shaping the dynamics of celestial bodies and the evolution of the cosmos. From Newton's apple to Einstein's spacetime curvature, our understanding of gravity has evolved significantly over the centuries, yet many mysteries remain. As we continue to unravel the secrets of the universe, the force of gravity will undoubtedly remain a central focus of scientific inquiry for generations to come.Thank you for joining me on this journey through the realm of gravitation. I hope this lecture has deepened your appreciation for the profound significance of gravity in shaping the cosmos. Let us continue to explore, question, and marvel at the wonders of the universe. Good day.
24e558bb-2bf4-4d72-86aa-91eaab7b2655	ceff43b3-ac8f-4bec-a00b-9560b8634647	Title: Understanding Gravitation: A Fundamental Force in the CosmosGood morning/afternoon/evening, ladies and gentlemen. Today, we embark on a journey through one of the fundamental forces that govern our universe: gravitation. From the humble apple falling from a tree to the majestic dance of galaxies across the cosmos, gravity shapes the very fabric of space and time. In this lecture, we'll explore the intricacies of gravity, its historical significance, its role in the cosmos, and its profound implications for our understanding of the universe.Let's begin with a simple observation: everything that has mass attracts other mass. This seemingly trivial statement encapsulates the essence of gravitation, as formulated by Sir Isaac Newton in his groundbreaking work, the Principia Mathematica. Newton's law of universal gravitation states that every particle in the universe attracts every other particle with a force that is directly proportional to the product of their masses and inversely proportional to the square of the distance between their centers.The concept of gravity is not a recent discovery. Throughout history, civilizations have grappled with the mysteries of celestial motion and the forces that govern them. Ancient civilizations such as the Greeks and the Babylonians pondered the motions of the stars and planets, attributing them to the whims of the gods. It wasn't until the scientific revolution of the 17th century that humanity began to unravel the true nature of gravitational forces.In 1687, Isaac Newton published his magnum opus, the Principia Mathematica, wherein he laid the groundwork for classical mechanics and the theory of universal gravitation. Newton's laws of motion provided a comprehensive framework for understanding the dynamics of objects on Earth and in the heavens. His law of universal gravitation, combined with his laws of motion, offered a unified explanation for the orbits of the planets, the motion of the tides, and the trajectory of projectiles.While Newton's theory of gravity reigned supreme for over two centuries, it wasn't until the early 20th century that its limitations became apparent. Enter Albert Einstein and his theory of general relativity. Einstein revolutionized our understanding of gravity by proposing that it is not merely a force between masses but rather a curvature of spacetime caused by the presence of mass and energy.According to general relativity, massive objects such as stars and planets warp the fabric of spacetime, much like placing a heavy ball on a stretched rubber sheet. This curvature of spacetime dictates the paths that objects follow, causing them to move along the curved trajectories we perceive as gravitational attraction. General relativity has been confirmed through numerous experiments and observations, from the bending of light around massive objects to the detection of gravitational waves rippling through the cosmos.The recent detection of gravitational waves by instruments such as LIGO and VIRGO has opened up new avenues for studying the universe. Gravitational waves are ripples in spacetime produced by cataclysmic events such as the collision of black holes or the merger of neutron stars. By detecting these waves, scientists can probe the most extreme phenomena in the cosmos and test the predictions of general relativity with unprecedented precision.In conclusion, gravitation stands as one of the cornerstones of modern physics, shaping the dynamics of celestial bodies and the evolution of the cosmos. From Newton's apple to Einstein's spacetime curvature, our understanding of gravity has evolved significantly over the centuries, yet many mysteries remain. As we continue to unravel the secrets of the universe, the force of gravity will undoubtedly remain a central focus of scientific inquiry for generations to come.Thank you for joining me on this journey through the realm of gravitation. I hope this lecture has deepened your appreciation for the profound significance of gravity in shaping the cosmos. Let us continue to explore, question, and marvel at the wonders of the universe. Good day.
252e5056-50e1-4b45-ab8c-933421212d72	551bb07c-8130-4bdc-9427-aecd69506a82	hello hello test matter is anything that occupies space and has mass all matter has inertia matter consists of proton neutrons and electrons these subatomic particles confined to pay an atom
1ebe83c3-56b1-4857-a6b2-5c1cdd708235	551bb07c-8130-4bdc-9427-aecd69506a82	call maarna
9c3d7a6c-aed3-45ab-81c9-a89cae6313f2	551bb07c-8130-4bdc-9427-aecd69506a82	Hello today we will learn about matter matter is anything that consist of mass and occupies space matter consists of proton electrons and neutrons these particles combine to form an atom matter consists of a collection of atoms these atoms can further be broken down into Fox Fox cannot be for the broken down these are fundamental unit of matter
3a914b71-59ef-4048-96db-c2a8b588f5e4	551bb07c-8130-4bdc-9427-aecd69506a82	hello this is a test transcription recording matter by
650a0f86-9bbe-49bd-943b-06b22be1f9b3	551bb07c-8130-4bdc-9427-aecd69506a82	hello this is a test transcription
438c2a3a-f941-44b4-8f45-e7a6ec4969c4	551bb07c-8130-4bdc-9427-aecd69506a82	hello test transcription
446c0a8f-2c3b-4633-ad93-6a65f3857ecb	551bb07c-8130-4bdc-9427-aecd69506a82	D3 D3 b hello hello
a84ce135-e30e-4b13-8f12-2f1a98af8301	551bb07c-8130-4bdc-9427-aecd69506a82	today we are going to learn matter of life matter is everything
ef5fec75-a952-4056-b57d-90e9b95d3dc0	551bb07c-8130-4bdc-9427-aecd69506a82	hello hello
ba71dff3-f18f-46c1-a845-838d7bce3c72	551bb07c-8130-4bdc-9427-aecd69506a82	Hello today we are going to learn about matter matter consists of electron proton neutron together these particles form the atom atoms constitute metal matter is anything that occupies space and has mass
c216b752-805e-41b4-8b5b-1d556c3d9810	db4e6032-71f7-401d-99d9-acd03206a887	Hello today we will learn about structure of atom atom is the understurptable part of the universe all matter is made up of atom atom consists of nucleus wear in the protons and the neutrons decide electrons revolve around this nucleus in a circular fashion there are orbitals which are the path that electrons follow Hello
08d8a136-6526-48b9-a940-f7c88213bd15	db4e6032-71f7-401d-99d9-acd03206a887	hello hello today we will learn about structure of atoms atoms consist of primary particle such as electrons neutrons and proton it consists of nucleus at its Centre then nucleus contains positively charged protons and the neutrali charge neutron then nucleus is extremely compared to the rest of the atoms and neutrons are tightly bound Together by strong nuclear force protons are positive the number of hydrogen atoms protons is one while an atom with 6 protons is carbon neutrons are electrically neutral particles found alongside Proton the contribute to the mass of the atom but do not affect its chemical properties significant isotopes are the elements having same number of proton but different number of Newton s are negative negatively charged particles that Orbit the nucleus in a specific parts this part is called as levels or shells there are different shells for various electrons and electrons are classified based on the shells that they revolved the number electrons in an atom is always equal to the number of proton the number of electrons in atom makes chemical reactions occur
f1be1943-9700-4d91-b528-1295c837398b	db4e6032-71f7-401d-99d9-acd03206a887	hello
2b50c75b-7db6-44a6-915e-eecca5287f9b	db4e6032-71f7-401d-99d9-acd03206a887	hello what are you doing hello what are you too f*** hello mera naam Bharat Hai hello mera naam Priyanka hai hello mera naam Rishabh hai hello mera naam Arnav hai Milind pithadia today we will learn Maru Naam Twinkle chhe Char Char bangadi wali gadi le hello aaj ham banaenge Aaj Ham banaenge Tahalka amlet amlet hello hello mera naam hello hello hello mera naam Bharat hai aur aaj ham Hello today we are going to learn we will see what are variables
bcc03b94-9875-4e6b-b01b-ef2b33ee7579	86c2ccc4-2452-4223-9ae5-ef612a4bed0f	hello hello hello hello my name is hello Hello today we are going to learn about atoms and the properties in the world of modern physics atoms are for the divided into molecules such as quarks quacks constitute the what you say Trance and protons hello hello this is hello today we are going to learn about intricacies Mera Naam Aaj Hum padhenge linear algebra Jahan Hum
3571ccbe-0e56-4d9f-be05-7db148c76f3b	86c2ccc4-2452-4223-9ae5-ef612a4bed0f	Bharat Prabhu this is Bharat Prabhu discuss about Enterprises of hello and we are
5abd9e69-bb0f-4adc-b25a-ea97434e851c	86c2ccc4-2452-4223-9ae5-ef612a4bed0f	hello hello hello hello hello
9cc3d87f-af7e-4ff6-905b-62dd7b313f36	86c2ccc4-2452-4223-9ae5-ef612a4bed0f	hello is Bharat Prabhu and today I am going to teach you linear Jabra when we will solve 2 simulta and understand how to actually go about
01d12726-dc43-4ce8-b87b-c4d07052cd7c	86c2ccc4-2452-4223-9ae5-ef612a4bed0f	hello I am going to let you all know how to solve Sim questions with two variables here we with two variables and two equations what we have to do is to find the value of both of both the Vari for doing that what we will do is we will equate the coefficients of one of the variables and then add or subtract both the equations depending on the science of that equated coefficient after doing that you will get the value of another variable this value for the variable we can then put in any of the equation value of the first equation that is the first variable baby sold to simultaneous equations to get the values of we can also use this kind of method to solve having equation having three Vari aur variables but it gets complex as we go beyond 3 variable scope for that we also screamers method where we use mattresses to solve are knowledge of mathematics
f53b0a18-c42e-4cbe-afb7-9a23cf248727	86c2ccc4-2452-4223-9ae5-ef612a4bed0f	hello hello hello hello hello hello this is trying to teach you all how actually it's solved question Marine we have the value of one equations and we need to find the value of another variable in this one we have
49a3af14-3fc8-4312-b7b8-22f6d257dc68	e77aa886-4f3f-409f-a99b-d95ac7a875ea	hello today we will study about in India political rights constitution include right to form partical parties right to and the right to equality before law the constitution also free speech expression subject today reasonable restrictions the right to equality before law and participant political process the include such rights as these rights for being a democratic country write what is right write is essentially and entitlement or a justified claim denotes what we are entitle to as it is individuals it is sometimes some it is something that we consider to be due to us something that must be upheld something that there is also society must recognize as being claim that must be applied this does not mean that everything that to be and necessary and desirable is a right I may want to wear use of my choice to school rather than the prescrib uniform I mean late Nights but does this not it does not mean that I have right to dress any school or written home when I choose to do so there is a distinction what I want and what I think I am entitle to and what can be design it rights rights are primary tho that I along with others regard to be necessary for Lead respect and dignity in fact one of the grounds on which rights have inclaimed present conditions that we collectively see as a source of self respect for example the right to livelihood may be considered necessary for living identity like dignity with life dignity being generally employed person economic get up Independence and search is central for his dignity
0a7090c2-0754-4877-b01e-ab5b5f11169b	990cd90d-9fef-434c-82b7-dbefc869f0e6	democracy is a system of government in which laws and leadership and measure undertakings of a state or other polity decided by the people of the people for the studies of contemporaries in nonliterate evidence suggest the democracy broadly speaking was practiced with bhangar gathers entry story Times the settle agriculture community is led to the iniqualities of wealth and power between non democratic forms of social thousands of years later in 6 century BCE relatively democratic form of government institute state of ethics by synthesis States with democratic governments prevent autocrates guarantee of fundamental right to individual rights all of our Rela political equality and rarely make warran Each Other as com greatest States they also better for the human development as measured by the indicator education provide more postulatory for the citizens and ensure a product
\.


--
-- Data for Name: Notes; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."Notes" ("notesId", "notesContent", "notesTitle", "lectureId") FROM stdin;
971cd63b-49d5-4519-9619-a4c40f9c87ce	Structure of the Atom\n\nKey Points:\n\n* The atom is the fundamental unit of matter.\n* The atom consists of a nucleus and electrons.\n* The nucleus is located at the center of the atom and contains protons and neutrons.\n* Protons have a positive charge, while neutrons have no charge.\n* Electrons have a negative charge and orbit the nucleus in specific energy levels.\n* The number of protons in an atom determines its atomic number and chemical properties.\n* The number of neutrons in an atom determines its isotope.\n* Isotopes are atoms of the same element with different numbers of neutrons.\n* Electrons occupy orbitals, which are regions of space where they are most likely to be found.\n* The arrangement of electrons in orbitals follows the Aufbau principle and Hund's rule.\n\nInsights and Examples:\n\n* The nucleus is extremely small compared to the rest of the atom.\n* The mass of an atom is mostly due to the protons and neutrons in the nucleus.\n* Electrons are responsible for the chemical properties of atoms.\n* The structure of the atom can be used to explain the periodic table of elements.\n* The study of atoms is essential for understanding chemistry, physics, and materials science.\n\nClarity and Coherence:\n\nThe notes are clear and concise, and they provide a comprehensive overview of the structure of the atom. The key points are summarized in a logical order, and the insights and examples help to illustrate the concepts. The notes are also coherent, with each point building on the previous one.	Structure of Atom	db4e6032-71f7-401d-99d9-acd03206a887
381669da-887d-423a-bfdb-c5ee5508b57c	Comprehensive Notes on Cybersecurity\n\nKey Points:\n\n* Cybersecurity encompasses practices, technologies, and policies to protect digital systems, networks, and data from unauthorized access, disruption, and exploitation.\n* The rise of the digital age has brought unprecedented connectivity and convenience, but also exposed us to new and evolving cyber threats.\n* Cyberattacks have the potential to disrupt critical infrastructure, compromise sensitive information, and undermine public trust in digital systems.\n* Cybersecurity is a multifaceted endeavor requiring a comprehensive approach involving technology, policy, education, and collaboration.\n* Key components of cybersecurity include risk management, authentication and access control, encryption, intrusion detection and prevention, incident response, and cyber hygiene.\n\nInsights and Examples:\n\n* Risk Management: Identifying and prioritizing risks to digital assets, such as data breaches, malware infections, and phishing attacks.\n* Authentication and Access Control: Verifying user identities through multi-factor authentication, biometrics, or role-based access control.\n* Encryption: Protecting data in transit and at rest using encryption algorithms, such as AES-256 or RSA.\n* Intrusion Detection and Prevention: Monitoring network traffic and system activity for suspicious behavior, such as unauthorized login attempts or malware activity.\n* Incident Response: Developing plans and procedures for responding to cybersecurity incidents, including containment, investigation, and recovery efforts.\n* Cyber Hygiene: Promoting best practices for maintaining secure systems, such as installing software updates, using strong passwords, and avoiding suspicious links.\n\nChallenges in Cybersecurity:\n\n* Evolving Cyber Threats: Cybercriminals are becoming increasingly sophisticated, using techniques like social engineering, ransomware, and supply chain attacks.\n* Expanded Attack Surface: The proliferation of connected devices and the Internet of Things (IoT) has created new avenues for exploitation and compromise.\n\nShared Responsibility:\n\n* Cybersecurity is a shared responsibility requiring collective action and collaboration across sectors and stakeholders.\n* Prioritizing cybersecurity awareness, education, and investment can build a more resilient and secure digital ecosystem.	Security	0bc8e4e8-4265-43c8-99dd-00d8c9dec7f7
881c15bf-4bd2-4f24-88f9-9ef2134f6106	Comprehensive Notes\n\nKey Points\n\n* Definition of Rights: Rights are inherent entitlements possessed by all individuals by virtue of their humanity, encompassing freedoms, protections, and opportunities essential for human flourishing.\n\n* Origins of Rights: The concept of rights has ancient roots in philosophical traditions and religious teachings, with the modern idea emerging after significant historical events like the Enlightenment and civil rights struggles.\n\n* Universal Declaration of Human Rights: Adopted in 1948, this landmark document proclaims the inalienable rights to which all human beings are entitled, including civil, political, economic, social, and cultural rights.\n\n* Characteristics of Rights:\n    * Indivisible, interrelated, and interdependent\n    * Universal, applying to all individuals regardless of characteristics\n    * Inherent, not granted by governments but intrinsic to human dignity\n\n* Challenges to Human Rights: Violations of rights continue to occur due to discrimination, oppression, poverty, conflict, and authoritarianism.\n\n* Importance of Human Rights: They are the bedrock of a just and equitable society, ensuring dignity, respect, and compassion for all individuals.\n\nInsights and Examples\n\n* The right to education is closely linked to the right to freedom of expression, as access to information is essential for informed citizenship.\n* The civil rights movement in the United States and the fight against apartheid in South Africa are examples of grassroots movements that have advanced the cause of human rights.\n\nClarity and Coherence\n\nThese notes provide a concise and structured overview of the key points covered in the resources, ensuring clarity and coherence for easy understanding.	Rights	e77aa886-4f3f-409f-a99b-d95ac7a875ea
845cc0d6-8328-4278-abc2-b24314ef4d29	Key Points on Democracy\n\nDefinition and Origins:\n\n* Democracy is a system of government where power is vested in the people, either directly or through elected representatives.\n* Its roots can be traced back to ancient Greece, particularly Athens, where citizens participated directly in decision-making.\n\nPrinciples:\n\n* Popular sovereignty: Power ultimately belongs to the people.\n* Political equality: All citizens have equal rights and opportunities to participate in political processes.\n* Majority rule: Decisions are made based on the will of the majority, while respecting minority rights.\n* Individual rights and freedoms: Democracy protects fundamental rights such as freedom of speech, assembly, and religion.\n\nModern Development:\n\n* The modern concept of democracy emerged during the Enlightenment era, influenced by philosophers like Locke, Rousseau, and Montesquieu.\n* Democratic movements in the 18th and 19th centuries led to the establishment of constitutional republics and parliamentary democracies.\n\nForms of Democracy:\n\n* Direct democracy: Citizens directly participate in decision-making through referendums and initiatives.\n* Representative democracy: Elected officials represent the interests of the people in legislative bodies.\n\nKey Features:\n\n* Free and fair elections\n* Rule of law\n* Protection of individual rights and freedoms\n* Independent judiciary\n* Vibrant civil society\n\nChallenges and Criticisms:\n\n* Political polarization\n* Voter apathy\n* Corruption\n* Inequality\n* Rise of authoritarianism and populism\n\nResilience and Adaptation:\n\n* Democracy is an adaptive system capable of evolving and responding to societal changes.\n* It provides avenues for peaceful political participation, dialogue, and social change.\n\nConclusion:\n\n* Democracy is a reflection of our collective aspirations for freedom, equality, and justice.\n* Upholding democratic values and principles is crucial for building inclusive, prosperous, and resilient societies.	Democracy	990cd90d-9fef-434c-82b7-dbefc869f0e6
3fe50e14-f0e1-46ed-96cb-6340e5af77e5	Matter: The Fundamental Building Block\n\nDefinition and Composition:\n* Matter encompasses everything that occupies space and has mass.\n* It consists of particles, primarily atoms and molecules.\n\nSubatomic Particles and Atoms:\n* Atoms are the smallest units of matter.\n* They comprise a nucleus containing protons and neutrons, surrounded by electrons.\n* Protons and neutrons determine the element of an atom.\n\nStates of Matter:\n* Solid: Particles are tightly packed, maintaining a fixed shape and volume.\n* Liquid: Particles are close together but can move past each other, allowing flow and assuming the shape of their container.\n* Gas: Particles are far apart and move freely, filling the available space.\n* Plasma: Ionized gas with equal numbers of positive and negative charges.\n\nMatter in the Cosmos:\n* Stars, galaxies, and cosmic dust are composed of matter.\n* The universe contains dark matter and dark energy, which are inferred through their gravitational effects.\n\nKey Points:\n* Matter is the fundamental building block of everything in the universe.\n* Atoms are the smallest units of matter, consisting of subatomic particles.\n* The states of matter (solid, liquid, gas, plasma) exhibit distinct properties.\n* Matter exists on various scales, from subatomic particles to cosmic structures.\n* Dark matter and dark energy are mysterious substances that influence the behavior of visible matter.\n\nInsights and Examples:\n* The periodic table organizes elements based on their atomic number, revealing patterns in their properties.\n* Solids are used in construction and engineering due to their rigidity.\n* Liquids are essential for life, as they form the basis of cells and bodily fluids.\n* Gases are used in various applications, such as fuel, refrigeration, and medical treatments.\n* Plasma is found in stars, lightning, and neon signs.\n* Dark matter and dark energy are still poorly understood but play a significant role in shaping the universe.	Matter around us	551bb07c-8130-4bdc-9427-aecd69506a82
\.


--
-- Data for Name: Quiz; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."Quiz" ("quizId", "quizName", "lectureId") FROM stdin;
7b1b726c-362a-47bb-9fe3-a82a9b38ab62	Security	0bc8e4e8-4265-43c8-99dd-00d8c9dec7f7
f1f5e6b8-5391-4b9c-9c7d-5a2f4fb8e12b	Matter around us	551bb07c-8130-4bdc-9427-aecd69506a82
7ad3b677-305a-48a4-85f5-0822c62757b5	Structure of Atom	db4e6032-71f7-401d-99d9-acd03206a887
c547acb9-6b6b-45a7-9566-e8fea3ac04da	Rights	e77aa886-4f3f-409f-a99b-d95ac7a875ea
\.


--
-- Data for Name: QuizAttempt; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."QuizAttempt" ("attemptId", "quizId", "attemptTimestamp", "userId") FROM stdin;
777814bd-00da-47b1-af2c-80b2d229b954	7ad3b677-305a-48a4-85f5-0822c62757b5	2024-03-29 14:38:14.585	c6e8fdfc-aff3-45c9-a82e-a223a802264f
0bde8916-40fe-428e-ae7c-0c9ed002d769	7ad3b677-305a-48a4-85f5-0822c62757b5	2024-03-29 19:15:16.667	3afacab1-dd21-441a-b996-3cdba2e245f9
a04e236e-baba-4d66-b96d-3fc682dbeb3d	f1f5e6b8-5391-4b9c-9c7d-5a2f4fb8e12b	2024-03-29 23:50:50.362	c6e8fdfc-aff3-45c9-a82e-a223a802264f
25569873-8031-4833-8f40-00157033e82d	f1f5e6b8-5391-4b9c-9c7d-5a2f4fb8e12b	2024-03-29 23:50:49.357	c6e8fdfc-aff3-45c9-a82e-a223a802264f
98e5c61f-f768-4095-90f2-1f4e3b782c9c	c547acb9-6b6b-45a7-9566-e8fea3ac04da	2024-03-30 04:39:08.91	4beca881-89a2-44c9-b22a-64e32c822a61
ea4876d4-9595-4759-9b7e-bc85ad5bded4	c547acb9-6b6b-45a7-9566-e8fea3ac04da	2024-03-30 04:39:09.788	797e98b3-6f5c-432f-8e3d-dac00b86278b
9a8b0522-42c4-44ee-a18f-5a01d0c79daa	c547acb9-6b6b-45a7-9566-e8fea3ac04da	2024-03-30 09:02:47.107	f27a96b8-8461-4dac-abef-5e559e2ad7ec
a330adee-0959-421e-a3af-dc60d32c3d1b	7ad3b677-305a-48a4-85f5-0822c62757b5	2024-03-30 10:19:26.016	f27a96b8-8461-4dac-abef-5e559e2ad7ec
80010bf0-17e6-49c3-9759-cc292add2c17	c547acb9-6b6b-45a7-9566-e8fea3ac04da	2024-04-02 03:52:55.807	3afacab1-dd21-441a-b996-3cdba2e245f9
\.


--
-- Data for Name: QuizQuestion; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."QuizQuestion" ("questionId", "quizId", "questionText", "questionOptions", "questionAnswerIndex") FROM stdin;
53866c00-e4fd-4d11-85c8-07669b822436	7ad3b677-305a-48a4-85f5-0822c62757b5	What is the central part of an atom called?	{Nucleus,"Electron cloud",Orbital,Proton}	0
8ec79ce2-80c8-4568-8164-c496fde9f659	7ad3b677-305a-48a4-85f5-0822c62757b5	Which subatomic particle has a positive charge?	{Electron,Neutron,Proton,Quark}	2
a311f4c1-656e-4f0f-9307-5ce7fee84892	7ad3b677-305a-48a4-85f5-0822c62757b5	What is the name of the model that describes electrons orbiting the nucleus in discrete energy levels?	{"Bohr model","Quantum mechanical model","Rutherford model","Aufbau model"}	0
2815601f-2ab5-41ea-a38f-8f86bb07dd81	7ad3b677-305a-48a4-85f5-0822c62757b5	Which of the following is NOT a rule governing the arrangement of electrons in an atom?	{"Aufbau principle","Hund's rule","Pauli exclusion principle","Heisenberg uncertainty principle"}	3
f5ee5cd4-c565-44f7-9c94-62e294f669a2	7ad3b677-305a-48a4-85f5-0822c62757b5	What is the significance of understanding the structure of the atom?	{"It helps explain the properties and behaviors of elements","It is essential for advancing fields like chemistry and physics","It provides insight into the fundamental workings of the universe","All of the above"}	3
8c8e5ac8-bb0f-4693-9035-013ca7a6f4a9	7b1b726c-362a-47bb-9fe3-a82a9b38ab62	What is the primary purpose of cybersecurity?	{"To protect digital systems from unauthorized access and exploitation","To enhance user experience and convenience","To promote innovation and technological advancement","To regulate the use of the internet"}	0
f6fef606-af79-48d8-8891-7280b7718607	7b1b726c-362a-47bb-9fe3-a82a9b38ab62	Which of the following is NOT a key component of cybersecurity?	{"Risk Management","Authentication and Access Control","Data Encryption","Social Media Marketing"}	3
c867f5ce-1050-4c88-b564-abf8d5d2cd51	7b1b726c-362a-47bb-9fe3-a82a9b38ab62	What is the significance of cybersecurity in today's digital world?	{"It safeguards critical infrastructure and sensitive information","It prevents cyberbullying and online harassment","It promotes economic growth and innovation","It ensures fair and equal access to the internet"}	0
87e8f2cd-0c0a-4bce-8470-b3320983ee79	7b1b726c-362a-47bb-9fe3-a82a9b38ab62	What are the ongoing challenges in the field of cybersecurity?	{"Evolving cyber threats and sophisticated tactics","Lack of skilled professionals and resources","Insufficient collaboration and information sharing","All of the above"}	3
59aabbbb-66f1-4490-9fc1-02a2cb2fce5f	7b1b726c-362a-47bb-9fe3-a82a9b38ab62	Who is responsible for maintaining cybersecurity?	{"Only governments and law enforcement agencies","Only large corporations and organizations","Only individuals and end-users","A shared responsibility across sectors and stakeholders"}	3
75482c21-31e6-426a-bdcb-be86b7bc1a60	c547acb9-6b6b-45a7-9566-e8fea3ac04da	What are human rights?	{"Inherent entitlements possessed by all individuals by virtue of their humanity","Rights granted by governments or institutions","Protections and opportunities that are essential for human flourishing","None of the above"}	0
3b92f91a-fc05-4a87-a126-9379eaf0e114	c547acb9-6b6b-45a7-9566-e8fea3ac04da	What is the significance of the Universal Declaration of Human Rights?	{"It proclaims the inalienable rights to which all human beings are entitled","It is the first international document to define human rights","It is the only document that has been ratified by all UN member states","None of the above"}	0
a16c9660-37e1-496c-af9f-b4c16bd1d9ee	c547acb9-6b6b-45a7-9566-e8fea3ac04da	Are human rights universal?	{"Yes, they apply to all individuals regardless of nationality, ethnicity, religion, or any other characteristic","No, they only apply to citizens of certain countries","Yes, but only in certain contexts","None of the above"}	0
d78921f3-c92a-4859-a673-0f5ab3f88dd3	c547acb9-6b6b-45a7-9566-e8fea3ac04da	What are some of the challenges to the fulfillment of human rights?	{"Discrimination, oppression, poverty, conflict, and authoritarianism","Lack of awareness about human rights","Insufficient resources to implement human rights","All of the above"}	0
7c089fa8-07c4-4ed3-803e-53e013126c7a	c547acb9-6b6b-45a7-9566-e8fea3ac04da	What is the role of individuals in upholding human rights?	{"Championing the cause of justice and equality","Educating themselves and others about human rights","Supporting organizations that work to protect human rights","All of the above"}	3
2390dbe3-fb30-4a38-848d-581bf9ac8f55	f1f5e6b8-5391-4b9c-9c7d-5a2f4fb8e12b	What are the three subatomic particles that make up an atom?	{"Protons, neutrons, and electrons","Electrons, protons, and quarks","Neutrons, protons, and quarks","Quarks, electrons, and neutrons"}	0
1bf8b780-bca0-4226-b692-80458047702b	f1f5e6b8-5391-4b9c-9c7d-5a2f4fb8e12b	Which state of matter has particles that are tightly packed and maintain a fixed shape and volume?	{Solid,Liquid,Gas,Plasma}	0
1394cb12-a735-4177-bdb8-6aceb2c60f39	f1f5e6b8-5391-4b9c-9c7d-5a2f4fb8e12b	What is the name of the substance that consists of ionized gas with equal numbers of positively and negatively charged particles?	{Solid,Liquid,Gas,Plasma}	3
ec2a602d-b401-47bc-a211-692cd7f5188c	f1f5e6b8-5391-4b9c-9c7d-5a2f4fb8e12b	What is the majority of the universe composed of?	{"Dark matter and dark energy","Stars and galaxies","Gas and dust",Plasma}	0
47ba9d36-3722-456b-8a66-4af9c5721d13	f1f5e6b8-5391-4b9c-9c7d-5a2f4fb8e12b	What is the smallest unit of matter?	{Atom,Molecule,Electron,Proton}	0
\.


--
-- Data for Name: QuizReport; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."QuizReport" ("reportId", "attemptId") FROM stdin;
\.


--
-- Data for Name: QuizResponse; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."QuizResponse" ("responseId", "attemptId", "questionId", "responseContent", "responseAccuracy") FROM stdin;
be0f8931-8ea7-4156-9ace-e70f670da45b	777814bd-00da-47b1-af2c-80b2d229b954	8ec79ce2-80c8-4568-8164-c496fde9f659		0
02af27e9-8381-4476-9843-32b69ff58f1a	777814bd-00da-47b1-af2c-80b2d229b954	f5ee5cd4-c565-44f7-9c94-62e294f669a2		0
74a14320-09bd-416a-a734-8d2346fbcfe8	777814bd-00da-47b1-af2c-80b2d229b954	2815601f-2ab5-41ea-a38f-8f86bb07dd81		0
c1e592ad-f2f7-48a0-b7d2-7671c4e91e0d	777814bd-00da-47b1-af2c-80b2d229b954	a311f4c1-656e-4f0f-9307-5ce7fee84892		0
97a242f8-da4d-4f4e-b985-e7ef4144b2f0	0bde8916-40fe-428e-ae7c-0c9ed002d769	8ec79ce2-80c8-4568-8164-c496fde9f659		1
bc840035-2108-4bc1-9dc4-bb95dfbf429a	0bde8916-40fe-428e-ae7c-0c9ed002d769	53866c00-e4fd-4d11-85c8-07669b822436		1
9e57d02a-fc09-4520-9b5e-c759a47a5876	0bde8916-40fe-428e-ae7c-0c9ed002d769	a311f4c1-656e-4f0f-9307-5ce7fee84892		0
694a93ff-f348-40a5-870f-3d9f0be8a699	0bde8916-40fe-428e-ae7c-0c9ed002d769	2815601f-2ab5-41ea-a38f-8f86bb07dd81		1
7f0a2d80-50e3-4d8b-a4c6-d74e14296791	25569873-8031-4833-8f40-00157033e82d	1394cb12-a735-4177-bdb8-6aceb2c60f39		0
b9240e84-553e-4ddc-8f39-fd2843cccfe6	25569873-8031-4833-8f40-00157033e82d	47ba9d36-3722-456b-8a66-4af9c5721d13		1
ca0ea3cc-87fa-4d63-92ba-e1061d14016d	25569873-8031-4833-8f40-00157033e82d	ec2a602d-b401-47bc-a211-692cd7f5188c		1
38cb598e-8092-46c0-97a6-dd368cfe8732	ea4876d4-9595-4759-9b7e-bc85ad5bded4	3b92f91a-fc05-4a87-a126-9379eaf0e114		0
985f00ba-08a2-46e0-8d2f-0fdd736fee26	ea4876d4-9595-4759-9b7e-bc85ad5bded4	d78921f3-c92a-4859-a673-0f5ab3f88dd3		0
692d2760-b62a-4482-8722-0ddef3212d79	ea4876d4-9595-4759-9b7e-bc85ad5bded4	a16c9660-37e1-496c-af9f-b4c16bd1d9ee		0
457632bf-4b82-4a06-9989-a05e93425b24	ea4876d4-9595-4759-9b7e-bc85ad5bded4	75482c21-31e6-426a-bdcb-be86b7bc1a60		0
8defa516-f7ce-46e0-a0a5-8bc13e13144e	98e5c61f-f768-4095-90f2-1f4e3b782c9c	3b92f91a-fc05-4a87-a126-9379eaf0e114		1
28e6d497-16ab-4242-9324-fa2bd3175132	98e5c61f-f768-4095-90f2-1f4e3b782c9c	75482c21-31e6-426a-bdcb-be86b7bc1a60		0
f8c6b2fd-7230-4797-a8df-ca9b4011d7ca	98e5c61f-f768-4095-90f2-1f4e3b782c9c	7c089fa8-07c4-4ed3-803e-53e013126c7a		0
8f320e5a-4d25-4d78-afc5-32ffaa88c434	a330adee-0959-421e-a3af-dc60d32c3d1b	f5ee5cd4-c565-44f7-9c94-62e294f669a2		0
7f99eb30-3b34-408b-b294-3bd4462a633f	80010bf0-17e6-49c3-9759-cc292add2c17	75482c21-31e6-426a-bdcb-be86b7bc1a60		1
06029452-b942-48df-bb0a-85e765de1468	80010bf0-17e6-49c3-9759-cc292add2c17	7c089fa8-07c4-4ed3-803e-53e013126c7a		0
83f844fc-e95d-4ea2-bbd5-22456bae13b6	80010bf0-17e6-49c3-9759-cc292add2c17	d78921f3-c92a-4859-a673-0f5ab3f88dd3		0
1e12c850-1531-4398-8635-66de22d8a9b5	777814bd-00da-47b1-af2c-80b2d229b954	53866c00-e4fd-4d11-85c8-07669b822436		0
\.


--
-- Data for Name: ReportTarget; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."ReportTarget" ("reportTargetId", "userId", "reportTargetEmail") FROM stdin;
\.


--
-- Data for Name: S3Object; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."S3Object" ("objectKey", "objectFileName", "objectSizeBytes", "objectContentType") FROM stdin;
example_object_key	example_file.txt	1024	text/plain
\.


--
-- Data for Name: S3Request; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public."S3Request" ("requestId", "objectKey", "requestMethod", "requestUserId") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: maamcoders
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
b5cd24a6-9013-42c5-9556-186e8ac46f9d	0c5e535bc8ce2ef1c0c97a58788ff811f2a5a5ffec6ac15bfc8ad91006323ca7	2024-03-28 05:48:12.868471+00	20240328054811_python_flask_init	\N	\N	2024-03-28 05:48:11.953797+00	1
\.


--
-- PostgreSQL database dump complete
--

